killall setup.sh
killall python3
./setup.sh &> out.file &
