# -*- coding: utf-8 -*-
"""
Created on Wed Nov 21 16:04:46 2018

@author: dell
"""
#%%
import redis
from pandas import DataFrame
import sys
import getopt
import os
#%%

class Redis:
    def __init__(self,host,port):
        self.host=host
        self.port=port
    def connect(self):
        try:
            pool = redis.ConnectionPool(host=self.host, port=self.port, db=0,decode_responses=True)
            r = redis.StrictRedis(connection_pool=pool)
        except redis.RedisError as e:# Exception,e:print(str(e))
            print("Error:"+str(e))
            sys.exit(2)
        try:
            connect_result=r.ping()
        except redis.ConnectionError:
            print("Error:can not connect to redis server with host:"+self.host+" and port:"+self.port)
            sys.exit(2)
        else:
            if connect_result==True:
                self.r=r
            else:
                print("Error:Ping the Redis server returns not True, check again.")
                sys.exit(2)
            
# #%%
# def IpExist(candidate_ip):# IpExist(candidate_ip)
#     ret=[]
#     if candidate_ip in iplist_DF:
#         ret.append("Ip found")
#     else:
#         ret.append("Ip not found")
#     return ret

# def IpNumGet(group_id):# IpNumGet(group_id)
#     ret=[]
#     if group_id in grpby_group_cnt_DF.index:
#         ret.append(grpby_group_cnt_DF[group_id])
#     return ret

# def AllIpGet(group_id):# AllIpGet(group_id)
#     ret=[]
#     if group_id in grpby_group_keys_DF:
#         for i in grpby_group_DF.get_group(group_id):
#             ret.append(i)
#     return ret
# #%%
# def main(argv):
#     global iplist_DF
#     global grpby_group_cnt_DF
#     global grpby_group_DF
#     global grpby_group_keys_DF
#     col_DF=["config_id","addr_pool_id","addr_type","ip_addr","location","mrl_ip",\
#             "link_id","encap_type","direction","outer_sport","outer_dport","outer_sip",\
#             "outer_dip","outer_smac","outer_dmac","inner_smac","inner_dmac",\
#             "is_valid","op_time"]
#     DF=DataFrame(None,columns=col_DF)
    
#     try:
#         opts,args=getopt.getopt(argv,"hf:g:",\
#                                 ["help","host=","port=","ip="])
#     except getopt.GetoptError:
#         print("stat_ip_redis.py --host <redis host> --port <redis port> --ip <ip_addr>"+"\n"+"\
#                          -f <statistics function> -g <group_id>"+"\n"+"\
#                          -h <call the help> --help <call the help>")
#         sys.exit(2)
#     for opt, arg in opts:
#         if opt in ("-h", "--help"):
#             print("stat_ip_redis.py --host <redis host> --port <redis port> --ip <ip_addr>\
#                              -f <statistics function> -g <group_id>")
#             print("-f <stat_func>:\te:IpExist\tn:IpNumGet\ta:AllIpGet")
#             sys.exit()
#         elif opt in ("--host"):
#             host=arg
#         elif opt in ("--port"):
#             port=arg
#         elif opt in ("-f"):
#             func=arg
#             if func not in ["e","n","a"]:
#                 print("Need inputting available statistics function requirements.")
#                 sys.exit()
#         elif opt in ("-g"):
#             group_id=arg
#         elif opt in ("--ip"):
#             ip_addr=arg
#     try:
#         host,port,func
#     except NameError:
#         print("Error:Need inputting -h <redis host> -p <redis port> -f <statistics function>")
#         sys.exit(2)
    
#     P=Redis(host,port)
#     P.connect()
#     scan_CANDIDATE=P.r.scan_iter(match="EFFECTIVE_RULE:IR_CANDIDATE_IP*")
#     for i in scan_CANDIDATE:
#         DF.loc[i]=P.r.get(i).split("\t")
    
#     if func=="e":#function of IpExist,need parameters:candidate_ip(ip_addr)
#         try:
#             ip_addr
#         except NameError:
#             print("Error:miss parameters")
#             sys.exit(2)
#         else:
#             iplist_DF=list(DF['ip_addr'].drop_duplicates())
#             return IpExist(ip_addr)
        
#     elif func=="n":#function of IpNumGet, need parameters:group_id
#         try:
#             group_id
#         except NameError:
#             print("Error:miss parameters")
#             sys.exit(2)
#         else:
#             ipgroup_sel_DF=DF[['addr_pool_id','ip_addr']].drop_duplicates()
#             grpby_group_DF=ipgroup_sel_DF["ip_addr"].groupby(ipgroup_sel_DF['addr_pool_id'])
#             grpby_group_cnt_DF=grpby_group_DF.count()
#             return IpNumGet(group_id)
        
#     elif func=="a":#function of AllIpGet, need parameters:group_id
#         try:
#             group_id
#         except NameError:
#             print("Error:miss parameters")
#             sys.exit(2)      
#         else:
#             ipgroup_sel_DF=DF[['addr_pool_id','ip_addr']].drop_duplicates()
#             grpby_group_DF=ipgroup_sel_DF["ip_addr"].groupby(ipgroup_sel_DF['addr_pool_id'])
#             grpby_group_keys_DF=grpby_group_DF.groups.keys()
#             return AllIpGet(group_id)


#%%
# if __name__ == "__main__":
#    stat_result=main(sys.argv[1:])
#    print(stat_result)
#    os._exit(0)

def IpExist(host,port,candidate_ip):
    P=Redis(host,port)
    P.connect()
    scan_CANDIDATE=P.r.scan_iter(match="EFFECTIVE_RULE:IR_CANDIDATE_IP*")
    for i in scan_CANDIDATE:
        DF.loc[i]=P.r.get(i).split("\t")
    iplist_DF=list(DF['ip_addr'].drop_duplicates())
    if candidate_ip in iplist_DF:
        return True
    else:
        return False

def IpNumGet(host,port,group_id):# IpNumGet(group_id)
    P=Redis(host,port)
    P.connect()
    scan_CANDIDATE=P.r.scan_iter(match="EFFECTIVE_RULE:IR_CANDIDATE_IP*")
    ipgroup_sel_DF=DF[['addr_pool_id','ip_addr']].drop_duplicates()
    grpby_group_DF=ipgroup_sel_DF["ip_addr"].groupby(ipgroup_sel_DF['addr_pool_id'])
    grpby_group_cnt_DF=grpby_group_DF.count()
    if group_id in grpby_group_cnt_DF.index:
        return grpby_group_cnt_DF[group_id]
    else
        return 0

def AllIpGet(host,port,group_id):# AllIpGet(group_id)
    P=Redis(host,port)
    P.connect()
    scan_CANDIDATE=P.r.scan_iter(match="EFFECTIVE_RULE:IR_CANDIDATE_IP*")
    for i in scan_CANDIDATE:
        DF.loc[i]=P.r.get(i).split("\t")
    ipgroup_sel_DF=DF[['addr_pool_id','ip_addr']].drop_duplicates()
    grpby_group_DF=ipgroup_sel_DF["ip_addr"].groupby(ipgroup_sel_DF['addr_pool_id'])
    grpby_group_keys_DF=grpby_group_DF.groups.keys()
    ret=list()
    if group_id in grpby_group_keys_DF:
        for i in grpby_group_DF.get_group(group_id):
            ret.append(i)
    return ret