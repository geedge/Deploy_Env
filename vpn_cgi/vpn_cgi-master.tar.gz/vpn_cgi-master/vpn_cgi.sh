killall setup.sh
./setup.sh &> /dev/null &
