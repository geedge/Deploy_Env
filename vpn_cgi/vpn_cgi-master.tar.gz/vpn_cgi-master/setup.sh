#!/bin/sh
while [[ "1" = "1" ]]; do
	python3 manage.py runserver 0:8090
done
